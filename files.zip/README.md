# Aimbot — Anti-Cheat Testing Tool

> **For educational and anti-cheat testing purposes only.**

---

## Repository Structure

```
loader.lua      ← paste this into your executor
core.lua        ← systems: math, config, save/load, target/aim/ping
ui.lua          ← all GUI code
features.lua    ← drawing, aimbot loop, ESP loop, boot
```

| File | Lines | Contents |
|------|-------|----------|
| `loader.lua` | 30 | Entry point — fetches and runs the three files as one chunk |
| `core.lua` | 770 | Math aliases, services, Defaults/Settings, save/load, player cache, target selection, aim spring + Kalman filter, ping cache |
| `ui.lua` | 1693 | GUI frame construction, all component factory functions, full widget wiring, applySettingsToUI, reset/save buttons |
| `features.lua` | 539 | Drawing pool getters, aimbot RenderStepped loop, ESP RenderStepped loop, boot call |

---

## Usage

1. Fork or clone this repo.
2. Open `loader.lua` and replace the `REPO` placeholder:
   ```lua
   local REPO = "https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/"
   ```
3. Enable **HTTP Requests** in your executor.
4. Paste `loader.lua` into your executor and run it.

### Why a loader?

All three files share `local` upvalues — `Settings`, `espBoxPool`, `startAimbot`, etc.
Lua locals cannot cross `loadstring` boundaries, so the loader fetches all three files,
joins them into one string with `table.concat`, then calls `loadstring` once.
The result is byte-identical to running the original single file.

### Why 3 files and not 2?

`ui.lua` forward-declares `local startAimbot, stopAimbot, startEsp, stopEsp` so toggle
callbacks can reference them; `features.lua` assigns the actual function bodies.
The load order must always be **core → ui → features**. Merging core + features into
one file would require it to wrap around ui.lua (non-contiguous), so 3 is the minimum
clean split.

---

## Features

- **Aimbot** — Blatant / Legit modes, spring-damper smoothing, Kalman prediction, adaptive latency compensation
- **ESP** — Box / Circle/Mark / Charm modes, team colour tinting, text overlay (name, HP%, distance)
- **Health Check** — filter targets by HP % range
- **Team Whitelist** — always-skip specific teams
- **Target Override** — suppresses aimbot during manual flicks
- **Save / Load** — settings persist via writefile / readfile
